

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import './App.css';
import HomeHeroSection from './Components/HomeHeroSection';
import FindMentorPage from "./Components/FindMentorPage";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomeHeroSection />} />
        <Route path="/find-a-mentor" element={<FindMentorPage />} />
      </Routes>
    </Router>
  );
}

export default App;

